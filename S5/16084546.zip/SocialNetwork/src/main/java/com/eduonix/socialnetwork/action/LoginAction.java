package com.eduonix.socialnetwork.action;

public class LoginAction {
	public String execute() {
		System.out.println("We are executing login action!");
		return "success";
	}
}
